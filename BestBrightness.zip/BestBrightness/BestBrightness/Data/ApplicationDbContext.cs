﻿using BestBrightness.Models;
using BestBrightness.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace BestBrightness.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Users> Users { get; set; }
        public DbSet<Products> Products { get; set; }
        public DbSet<InventoryItem> InventoryItem { get; set; }
        public DbSet<LoginViewModel> LoginViewModel { get; set; }
        public DbSet<RegisterViewModel> RegisterViewModel { get; set; }
        public DbSet<SaleViewModel> SaleViewModel { get; set; }
        public DbSet<InventoryViewModel> InventoryViewModel { get; set; }
        public DbSet<ProductUploadViewModel> ProductUploadViewModel { get; set; }
        public DbSet<RegisterSalespersonViewModel> RegisterSalespersonViewModel { get; set; }
        public DbSet<SalespersonDetailsViewModel> SalespersonDetailsViewModel { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
    }
}
