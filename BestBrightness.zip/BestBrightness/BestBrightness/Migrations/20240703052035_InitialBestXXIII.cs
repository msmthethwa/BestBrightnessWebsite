﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BestBrightness.Migrations
{
    /// <inheritdoc />
    public partial class InitialBestXXIII : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
