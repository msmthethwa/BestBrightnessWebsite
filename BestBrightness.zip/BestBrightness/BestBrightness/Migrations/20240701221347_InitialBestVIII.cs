﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BestBrightness.Migrations
{
    /// <inheritdoc />
    public partial class InitialBestVIII : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "SalespersonDetailsViewModel",
                columns: table => new
                {
                    SalespersonId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DefaultPassword = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SalespersonDetailsViewModel", x => x.SalespersonId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SalespersonDetailsViewModel");
        }
    }
}
