﻿using System.ComponentModel.DataAnnotations;

namespace BestBrightness.Models
{
    public class Products
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string Description { get; set; }

        [Required]
        public int StockLevel { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        [Required]
        public DateTime LastUpdatedDate { get; set; }

        public string LastUpdatedBy { get; set; }

        public string SalespersonId { get; set; }
    }
}
