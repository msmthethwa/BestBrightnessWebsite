﻿using Microsoft.AspNetCore.Mvc;
using BestBrightness.ViewModels;
using BestBrightness.Data;
using BestBrightness.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace BestBrightness.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private static List<InventoryViewModel> _inventory = new List<InventoryViewModel>();

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Admin/Profile
        public IActionResult Profile()
        {
            var currentUser = _context.Users.FirstOrDefault(u => u.Username == User.Identity.Name);
            if (currentUser == null)
            {
                return NotFound();
            }

            var model = new ProfileViewModel
            {
                Username = currentUser.Username,
                FullName = currentUser.FullName,
                Role = currentUser.Role,
                CreatedAt = currentUser.CreatedAt
            };

            return View(model);
        }

        // POST: Admin/Profile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(ProfileViewModel model)
        {
            if (ModelState.IsValid)
            {
                var currentUser = _context.Users.FirstOrDefault(u => u.Username == User.Identity.Name);
                if (currentUser == null)
                {
                    return NotFound();
                }

                currentUser.FullName = model.FullName;

                if (!string.IsNullOrEmpty(model.NewPassword))
                {
                    currentUser.Password = model.NewPassword;
                }

                _context.Users.Update(currentUser);
                await _context.SaveChangesAsync();

                TempData["ProfileUpdateMessage"] = "Profile updated successfully.";
                return RedirectToAction("Profile");
            }

            return View(model);
        }


        // GET: Admin/UploadProduct
        public IActionResult UploadProduct()
        {
            return View();
        }

        // POST: Admin/UploadProduct
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadProduct(ProductUploadViewModel model)
        {
            if (ModelState.IsValid)
            {
                var newProduct = new Products
                {
                    Name = model.ProductName,
                    Description = model.ProductDescription,
                    StockLevel = model.StockLevel,
                    Price = model.Price,
                    LastUpdatedBy = "Admin",
                    LastUpdatedDate = DateTime.Now,
                    SalespersonId = "default_salesperson_id" // Set a default value
                };

                _context.Products.Add(newProduct);
                await _context.SaveChangesAsync();

                return RedirectToAction("AdminPage");
            }

            return View(model);
        }

        // GET: Admin/UpdateProduct/{id}
        public async Task<IActionResult> UpdateProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var model = new ProductUploadViewModel
            {
                ProductName = product.Name,
                ProductDescription = product.Description,
                StockLevel = product.StockLevel,
                Price = product.Price
            };

            ViewBag.ProductId = id;
            return View(model);
        }

        // POST: Admin/UpdateProduct/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateProduct(int id, ProductUploadViewModel model)
        {
            if (ModelState.IsValid)
            {
                var product = await _context.Products.FindAsync(id);
                if (product == null)
                {
                    return NotFound();
                }

                product.Name = model.ProductName;
                product.Description = model.ProductDescription;
                product.StockLevel = model.StockLevel;
                product.Price = model.Price;
                product.LastUpdatedBy = "Admin";
                product.LastUpdatedDate = DateTime.Now;

                _context.Products.Update(product);
                await _context.SaveChangesAsync();

                return RedirectToAction("AdminPage");
            }

            ViewBag.ProductId = id;
            return View(model);
        }

        // GET: Admin/AdminPage
        public IActionResult AdminPage()
        {
            var products = _context.Products
                .Select(p => new InventoryViewModel
                {
                    Id = p.Id,
                    ProductName = p.Name,
                    ProductDescription = p.Description,
                    StockLevel = p.StockLevel,
                    Price = p.Price,
                    LastUpdatedBy = p.LastUpdatedBy,
                    LastUpdatedDate = p.LastUpdatedDate
                })
                .ToList();

            return View(products);
        }


        // GET: Admin/RegisterSalesperson
        public IActionResult RegisterSalesperson()
        {
            var viewModel = new RegisterSalespersonViewModel
            {
                SalespersonId = GenerateSalespersonId(),
                DefaultPassword = GenerateDefaultPassword()
            };

            return View(viewModel);
        }

        // POST: Admin/RegisterSalesperson
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegisterSalesperson(RegisterSalespersonViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if the username (email) is already registered
                if (await _context.Users.AnyAsync(u => u.Username == model.Email))
                {
                    ModelState.AddModelError(string.Empty, "Email address is already registered. Please use a different email address.");
                    return View(model);
                }

                var user = new Users
                {
                    Username = model.Email,
                    Password = model.DefaultPassword,
                    FullName = $"{model.FirstName} {model.LastName}", // Store the full name
                    Role = "Salesperson",
                    SalespersonId = model.SalespersonId
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                // Redirect to a page displaying the salesperson ID and default password
                return RedirectToAction("SalespersonDetails", new { salespersonId = user.SalespersonId, defaultPassword = model.DefaultPassword });
            }

            return View(model);
        }

        // GET: Admin/EditSalesperson/{id}
        public IActionResult EditSalesperson(string id)
        {
            var user = _context.Users.FirstOrDefault(u => u.SalespersonId == id && u.Role == "Salesperson");
            if (user == null)
            {
                return NotFound();
            }

            var viewModel = new RegisterSalespersonViewModel
            {
                SalespersonId = user.SalespersonId,
                FirstName = GetFirstNames(user.FullName),
                LastName = GetLastName(user.FullName),
                Email = user.Username,
                DefaultPassword = user.Password // Populate password for display/edit
                                                // You can add more properties here if needed
            };

            return View(viewModel);
        }

        // POST: Admin/EditSalesperson/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditSalesperson(string id, RegisterSalespersonViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = _context.Users.FirstOrDefault(u => u.SalespersonId == id && u.Role == "Salesperson");
                if (user == null)
                {
                    return NotFound();
                }

                // Update the user's information
                user.Username = model.Email;
                user.FullName = $"{model.FirstName} {model.LastName}";
                user.Password = model.DefaultPassword; // Update password if edited

                // Save changes to the database
                _context.Users.Update(user);
                await _context.SaveChangesAsync();

                // Redirect to the salesperson details page or any other appropriate page
                TempData["EditSuccessMessage"] = "Salesperson details updated successfully."; // Store message in TempData
                return RedirectToAction("SalespersonDetails", new { salespersonId = user.SalespersonId, defaultPassword = user.Password });
            }

            return View(model);
        }


        // GET: Admin/SalespersonDetails/{salespersonId}
        public IActionResult SalespersonDetails(string salespersonId, string defaultPassword)
        {
            var user = _context.Users.FirstOrDefault(u => u.SalespersonId == salespersonId);
            if (user == null)
            {
                return NotFound();
            }

            var viewModel = new SalespersonDetailsViewModel
            {
                SalespersonId = user.SalespersonId,
                FirstNames = GetFirstNames(user.FullName),
                LastName = GetLastName(user.FullName),
                Email = user.Username,
                DefaultPassword = defaultPassword // Pass the default password
            };

            return View(viewModel);
        }

        // GET: Admin/ViewSalespersons
        public IActionResult ViewSalespersons()
        {
            var salespersons = _context.Users
                .Where(u => u.Role == "Salesperson")
                .Select(u => new SalespersonDetailsViewModel
                {
                    SalespersonId = u.SalespersonId,
                    FirstNames = GetFirstNames(u.FullName),
                    LastName = GetLastName(u.FullName),
                    Email = u.Username,
                    DefaultPassword = u.Password
                })
                .ToList();

            return View(salespersons);
        }

        // Static helper methods to get first names and last name
        private static string GetFirstNames(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
                return string.Empty;

            var names = fullName.Split(' ');
            return names.Length > 1 ? string.Join(" ", names.Take(names.Length - 1)) : names[0];
        }

        private static string GetLastName(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
                return string.Empty;

            var names = fullName.Split(' ');
            return names.Length > 1 ? names.Last() : string.Empty;
        }

        // GET: Admin/DeleteSalesperson/{id}
        public async Task<IActionResult> DeleteSalesperson(string id)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.SalespersonId == id && u.Role == "Salesperson");
            if (user == null)
            {
                return NotFound();
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return RedirectToAction("ViewSalespersons");
        }


        // Method to generate a unique salesperson ID
        private string GenerateSalespersonId()
        {
            var random = new Random();
            string id;
            do
            {
                id = random.Next(100000, 999999).ToString();
            } while (_context.Users.Any(u => u.SalespersonId == id));

            return id;
        }

        // Method to generate a default password
        private string GenerateDefaultPassword()
        {
            // Generate a default password (you can customize the logic as needed)
            return Guid.NewGuid().ToString().Substring(0, 8); // Example logic for generating a default password
        }

        // Method to compute SHA256 hash (if needed)
        private static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // Method to get the inventory list
        public static List<InventoryViewModel> GetInventory()
        {
            return _inventory;
        }

        // Method to update the inventory list
        public static void UpdateInventory(List<InventoryViewModel> updatedInventory)
        {
            _inventory = updatedInventory;
        }

        // POST: Admin/DeleteProduct/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return RedirectToAction("AdminPage");
        }
    }
}
