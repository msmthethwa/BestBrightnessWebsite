﻿using BestBrightness.Models;
using System.Collections.Generic;

namespace BestBrightness.ViewModels
{
    public class CartViewModel
    {
        public List<CartItem> Items { get; set; } = new List<CartItem>();
    }
}
