﻿using System.ComponentModel.DataAnnotations;

namespace BestBrightness.ViewModels
{
    public class ProductUploadViewModel
    {
        [Key]
        public string ProductName { get; set; }

        public string ProductDescription { get; set; }

        public int StockLevel { get; set; }

        [DataType(DataType.Currency)]
        public decimal Price { get; set; }
    }
}
