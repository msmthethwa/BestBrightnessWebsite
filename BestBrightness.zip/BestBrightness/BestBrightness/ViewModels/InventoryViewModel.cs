﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BestBrightness.ViewModels
{
    public class InventoryViewModel
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Product Name")]
        public string ProductName { get; set; }

        [Display(Name = "Description")]
        public string ProductDescription { get; set; }

        [Display(Name = "Stock Level")]
        public int StockLevel { get; set; }

        [Display(Name = "Price")]
        public decimal Price { get; set; }

        [Display(Name = "Last Updated Date")]
        public DateTime LastUpdatedDate { get; set; }

        [Display(Name = "Last Updated By")]
        public string LastUpdatedBy { get; set; }

        [Display(Name = "Salesperson ID")]
        public string SalespersonId { get; set; }

        // Constructor to initialize default values if needed
        public InventoryViewModel()
        {
            LastUpdatedDate = DateTime.Now; // Initialize LastUpdatedDate to current date/time
        }

        // Predefined threshold for low stock
        public int LowStockThreshold { get; set; } = 10; 
    }

}
